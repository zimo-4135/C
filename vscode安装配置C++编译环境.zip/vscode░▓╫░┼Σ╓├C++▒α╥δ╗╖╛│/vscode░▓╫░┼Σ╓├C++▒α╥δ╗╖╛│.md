# vscode安装配置C++编译环境

## 0. 引言

近段时间因为想学习C++，就在电脑上下载了vscode，但是才发现还没开始就结束了：环境配置不简单，一直没有达到我想要的结果。但是人不能轻言放弃，经过这几天的折腾，对环境配置上还是稍有了解，于是把整个过程给记录一下，方便与其他有兴趣的人一起交流，也方便下一次安装时有迹可循。话不多说，咱们接着往下看。

## 1. 软件准备

我是在win10系统上边安装的vscode，系统的不同的，仅供参考。

1.  [vscode](https://code.visualstudio.com/Download)
2. [MinGW编译器](https://sourceforge.net/projects/mingw-w64/files/mingw-w64/mingw-w64-release/): 下载最新版本即可（win用zip后缀文件）

## 2. 软件安装

### 1.vscode

1. 在官网下载安装包之后双击，可直接安装，和其他软件一样记得更改安装路径，不建议安装在C盘
2. 安装完成之后进入插件商店，搜索到插件之后，点击 **安装（install）** 插件![image-20220331105615467](Picture/image-20220331105615467-16486953780931.png)
   - 插件作用：
     - 名称: Chinese (Simplified) (简体中文) Language Pack for Visual Studio Code —— 中文转换插件
     - 名称: [Deprecated] Bracket Pair Colorizer 2 —— 彩虹括号扩展插件，支持括号自定义颜色
     - 名称: C/C++ —— 语言拓展核心插件, 支持代码补全和高亮
     - 名称: Code Runner —— 代码运行器，比vscode自身编译速度快
       - 运行代码：
         - 键盘快捷键 **Ctrl+Alt+N**
         - 快捷键 **F1** 调出 **命令面板**, 然后输入 **Run Code**
         - 在编辑区，右键选择 **Run Code**
         - 在左侧的文件管理器，右键选择 **Run Code**
         - 右上角的运行小三角按钮
       - 停止代码：
         - 键盘快捷键 **Ctrl+Alt+M**
         - 快捷键 **F1** 调出 **命令面板**, 然后输入 **Stop Code Run**
         - 在Output Channel，右键选择 **Stop Code Run**
     - 名称: indent-rainbow —— 彩虹缩进，便于识别代码前的缩进错误
     - 名称: Path Intellisense —— 路径提示
     - 名称: Rainier —— 颜色主题
     - 名称: vscode-icons —— code图标, 增加辨识

### 2. MinGW

这个编译器，下载之后解压，放到电脑的某个盘中，文件的路径不要设置中文名![image-20220331112129883](Picture/image-20220331112129883-16486968919012.png)

## 3. 环境设置

1. 打开vscode，创建 `launch.json 文件和 tasks.json 文件，注意后面这个文件有 s`

   - 我的 `launch.json` 文件如下：

   ```
   {
       "version": "0.2.0",
       "configurations": [
           {
               "name": "(gdb) Launch",    // 配置名称，将会在启动配置的下拉菜单中显示
               "type": "cppdbg",          // 配置类型，这里只能为cppdbg
               "request": "launch",       // 请求配置类型，可以为launch（启动）或attach（附加）
               "program": "D:\\C++_WorkSpace\\.build\\${fileBasenameNoExtension}.exe",// 将要进行调试的程序的路径，这个文件路径是我存放生成的 .exe 文件的路径，路径里不能出现中文
               "args": [],                // 程序调试时传递给程序的命令行参数，一般设为空即可
               "stopAtEntry": false,      // 设为true时程序将暂停在程序入口处，一般设置为false
               "cwd": "${workspaceRoot}", // 调试程序时的工作目录，一般为${workspaceRoot}即代码所在目录
               "environment": [],
               "externalConsole": true,   // 调试时是否显示控制台窗口，一般设置为true显示控制台
               "MIMode": "gdb",
               "miDebuggerPath": "C:\\MinGW\\bingdb.exe",// miDebugger的路径，注意这里要与MinGw的路径对应（上边图里边圈出来的那个）
               "preLaunchTask": "g++",    // 调试会话开始前执行的任务，一般为编译程序，c++为g++, c为gcc
               "setupCommands": [
                   {
                       "description": "Enable pretty-printing for gdb",
                       "text": "-enable-pretty-printing",
                       "ignoreFailures": true
                   }
               ]
           }
       ]
   }
   ```

   - 我的 `tasks.json` 文件如下：

     ```
     {
     	"version": "2.0.0",
     	"tasks": [
     		{
     			"type": "cppbuild",
     			"label": "C/C++: cpp.exe 生成活动文件",
     			"command": "C:\\MinGW\\bin\\cpp.exe",		//此处的路径还是红框框标出来的编译器路径
     			"args": [
     				"-fdiagnostics-color=always",
     				"-g",
     				"${file}",
     				"-o",
     				"D:\\C++_WorkSpace\\.build\\${fileDirname}\\${fileBasenameNoExtension}.exe"						//这个路径是说明我将生成的 .exe 文件存放的路径，注意路径中不能出现中文，与launch文件中的路径对应
     			],
     			"options": {
     				"cwd": "${fileDirname}"
     			},
     			"problemMatcher": [
     				"$gcc"
     			],
     			"group": "build",
     			"detail": "编译器: C:\\MinGW\\bin\\cpp.exe"		//此处的路径还是红框框标出来的编译器路径
     			//使用时将里边的注释删除！！！
     		}
     	]
     }
     ```

     **注意**：编译器路径和编译后生成的文件路径都==不能==出现中文！！！

2. 在设置中打开用户设置，再搜索框中输入 `encoding`，勾选 `Auto Guess Encoding`选项，设置默认编码语言，这样能防止再中文编码是出现乱码情况（windows系统使用的编码格式是GBK，切换成其他的语言之后可能会导致电脑上的中文出现问题，这里就没有测试，我是直接让编译器的格式和window一样，省掉麻烦）![image-20220331112623145](Picture/image-20220331112623145-16486971846693.png)![image-20220331124845974](Picture/image-20220331124845974.png)

   接下来还要设置 Code Runner 里边的设置，使用它的终端进行输出![image-20220331131255218](Picture/image-20220331131255218-16487035771361-16487038977832-16487039474824.png)![image-20220331131825021](Picture/image-20220331131255218-16487035771361-16487038977832-16487039474824.png)

   ## 4. 开启码农生活

   接下来就能愉快的写代码啦![image-20220331132740452](Picture/image-20220331132740452-16487044640805.png)

   我的文件结构基本上就是这样

   ## 5. 结语

   开始就是最难的，但是慢慢来，熟悉了就好。配置文件可以反复用。
   
   小白刚刚开始接触，如有什么不足的地方，还请路过的高手指点一二。